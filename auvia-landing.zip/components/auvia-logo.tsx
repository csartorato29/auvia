interface AuviaLogoProps {
  className?: string
  variant?: "default" | "white" | "dark"
  size?: "sm" | "md" | "lg" | "xl"
}

export function AuviaLogo({ className = "", variant = "default", size = "md" }: AuviaLogoProps) {
  const sizeClasses = {
    sm: "w-32 h-10 md:w-40 md:h-12",
    md: "w-40 h-12 md:w-56 md:h-16 lg:w-64 lg:h-18",
    lg: "w-48 h-14 md:w-72 md:h-20 lg:w-80 lg:h-22",
    xl: "w-56 h-16 md:w-80 md:h-22 lg:w-96 lg:h-24",
  }

  const colors = {
    default: {
      primary: "#D4AF37",
      secondary: "#B8941F",
      accent: "#0D2B3E",
      text: "#FFFFFF",
    },
    white: {
      primary: "#FFFFFF",
      secondary: "#F0F0F0",
      accent: "#CCCCCC",
      text: "#FFFFFF",
    },
    dark: {
      primary: "#000000",
      secondary: "#333333",
      accent: "#666666",
      text: "#000000",
    },
  }

  const currentColors = colors[variant]

  return (
    <div className={`${sizeClasses[size]} ${className} flex flex-col items-center justify-center relative mx-auto`}>
      {/* Main Logo Container */}
      <div className="relative z-10 flex flex-col items-center w-full max-w-full">
        {/* Text Logo - Clean and Minimal */}
        <div className="text-center w-full flex flex-col items-center">
          <h1 className="font-playfair text-2xl sm:text-3xl md:text-4xl lg:text-5xl xl:text-6xl font-bold tracking-[0.1em] sm:tracking-[0.2em] leading-tight mb-2 sm:mb-3">
            <span
              className="text-transparent bg-clip-text bg-gradient-to-r from-[#D4AF37] via-[#F4D03F] to-[#B8941F] block"
              style={{
                filter: "drop-shadow(0 2px 4px rgba(0,0,0,0.3))",
              }}
            >
              AUVIA
            </span>
          </h1>

          {/* Elegant Separator */}
          <div className="flex items-center justify-center mb-2 sm:mb-3">
            <div className="h-px bg-gradient-to-r from-transparent via-[#D4AF37] to-transparent w-12 sm:w-16 md:w-24" />
            <div className="w-1 h-1 sm:w-1.5 sm:h-1.5 bg-[#D4AF37] rounded-full mx-2 sm:mx-3 md:mx-4" />
            <div className="h-px bg-gradient-to-r from-transparent via-[#D4AF37] to-transparent w-12 sm:w-16 md:w-24" />
          </div>

          <p className="font-inter text-xs sm:text-sm md:text-base lg:text-lg font-semibold tracking-[0.3em] sm:tracking-[0.5em] text-[#D4AF37] opacity-90 mb-1 sm:mb-2">
            GROUP
          </p>

          {/* Tagline */}
          <p className="font-inter text-[10px] sm:text-xs md:text-sm font-medium tracking-[0.2em] sm:tracking-[0.3em] text-gray-400 opacity-80 hidden sm:block">
            COMMERCIAL EXCELLENCE
          </p>
        </div>
      </div>
    </div>
  )
}
