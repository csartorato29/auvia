import type React from "react"
import type { Metadata } from "next"
import "./globals.css"

export const metadata: Metadata = {
  title: "Auvia Group | Conglomerado de Excelência Comercial Premium",
  description:
    "Soluções comerciais de elite para empresas de médio e grande porte. SDRs qualificados, consultoria estratégica e metodologia proprietária.",
  keywords: "auvia group, vendas premium, SDR elite, consultoria comercial, operações de vendas, empresas premium",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="pt-BR">
      <body className="antialiased">{children}</body>
    </html>
  )
}
